"""Optional UI acceptance test and reproducible, unedited demo recording.

Requires: pip install playwright; python -m playwright install chromium ffmpeg
Run: python -m tests.browser_demo [--channel chrome]
"""
import argparse
import json
import tempfile
import threading
from pathlib import Path

from playwright.sync_api import sync_playwright, expect

from app import make_server


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--channel", default=None)
    args = parser.parse_args()
    artifacts = Path(__file__).resolve().parents[1] / "artifacts"
    artifacts.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        server = make_server(Path(tmp) / "demo.db", port=0, delay=.35)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True, channel=args.channel)
                context = browser.new_context(viewport={"width":1440,"height":1000},
                                              record_video_dir=str(artifacts / "recordings"),
                                              record_video_size={"width":1440,"height":1000})
                page = context.new_page()
                errors = []
                page.on("pageerror", lambda exc: errors.append(str(exc)))
                page.goto(f"http://127.0.0.1:{server.server_port}")
                expect(page.get_by_role("heading", name="Hand off the task.")).to_be_visible()
                page.screenshot(path=str(artifacts / "home.png"), full_page=True)
                page.wait_for_timeout(1500)  # Recording pacing; assertions below wait on actual state.

                page.get_by_role("button", name="Register latest invoice").click()
                page.get_by_label("Test recovery").select_option("commit_timeout")
                page.wait_for_timeout(1000)
                page.get_by_role("button", name="Run task").click()
                expect(page.locator(".execution")).to_be_visible()
                page.locator(".execution").scroll_into_view_if_needed()
                expect(page.locator("#execution .pill.completed")).to_be_visible(timeout=15000)
                expect(page.locator(".outcome")).to_contain_text("2,480.00")
                expect(page.locator(".timeline")).to_contain_text("Safe retry scheduled")
                page.screenshot(path=str(artifacts / "verified-run.png"), full_page=True)
                page.wait_for_timeout(2500)
                page.get_by_role("button", name="Original invoice").click()
                expect(page.locator("#source-content")).to_contain_text("Amount: 2480.00")
                page.wait_for_timeout(1500)
                page.get_by_role("button", name="Close source document").click()

                page.get_by_role("button", name="Approval handoff").click()
                page.get_by_label("Test recovery").select_option("none")
                page.get_by_role("button", name="Run task").click()
                expect(page.get_by_role("button", name="Approve record")).to_be_visible(timeout=15000)
                page.locator(".execution").scroll_into_view_if_needed()
                page.screenshot(path=str(artifacts / "approval.png"), full_page=True)
                page.wait_for_timeout(1500)
                page.get_by_role("button", name="Approve record").click()
                expect(page.locator("#execution .pill.completed")).to_be_visible(timeout=15000)
                expect(page.locator(".outcome")).to_contain_text("12,500.00")
                page.wait_for_timeout(1500)

                page.get_by_role("button", name="Missing information").click()
                page.get_by_role("button", name="Run task").click()
                expect(page.get_by_label("Your answer")).to_be_visible(timeout=15000)
                page.locator(".execution").scroll_into_view_if_needed()
                page.wait_for_timeout(1000)
                page.get_by_label("Your answer").fill("2026-11-02")
                page.get_by_role("button", name="Continue").click()
                expect(page.locator("#execution .pill.completed")).to_be_visible(timeout=15000)
                expect(page.locator(".outcome")).to_contain_text("2026-11-02")
                page.wait_for_timeout(1500)

                page.get_by_role("button", name="Summarize all invoices").click()
                page.get_by_label("Test recovery").select_option("inbox_outage")
                page.get_by_role("button", name="Run task").click()
                expect(page.locator("#execution .pill.completed")).to_be_visible(timeout=15000)
                page.locator(".execution").scroll_into_view_if_needed()
                expect(page.locator(".outcome")).to_contain_text("4,320.00")
                expect(page.locator(".timeline")).to_contain_text("Switching to archive")
                page.wait_for_timeout(2000)

                page.get_by_role("button", name="Company ledger", exact=False).click()
                expect(page.locator("tbody tr")).to_have_count(3)
                page.screenshot(path=str(artifacts / "ledger.png"), full_page=True)
                page.wait_for_timeout(2000)
                page.get_by_role("button", name="Run history", exact=False).click()
                expect(page.locator(".history-card")).to_have_count(4)
                page.wait_for_timeout(1500)
                page.get_by_role("button", name="Source inbox", exact=False).click()
                expect(page.locator(".source-card")).to_have_count(5)
                page.wait_for_timeout(1500)
                page.get_by_role("button", name="Task worker", exact=False).click()

                for width, height in ((390,844), (768,1024)):
                    page.set_viewport_size({"width":width,"height":height})
                    page.screenshot(path=str(artifacts / f"responsive-{width}.png"), full_page=True)
                    assert page.evaluate("document.documentElement.scrollWidth <= window.innerWidth"), "Horizontal overflow"
                assert not errors, f"Browser errors: {errors}"
                (artifacts / "demo-traces.json").write_text(json.dumps(server.engine.store.runs(), indent=2), encoding="utf-8")
                video = page.video
                context.close()
                video.save_as(str(artifacts / "relay-demo.webm"))
                video.delete()
                browser.close()
                print("Browser acceptance passed: recovery, approval, clarification, summary, ledger, sources, history, responsive layout.")
                print(f"Demo recording: {artifacts / 'relay-demo.webm'}")
        finally:
            server.shutdown()
            server.server_close()
            thread.join()


if __name__ == "__main__":
    main()
