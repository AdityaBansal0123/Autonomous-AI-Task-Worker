import json
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from pathlib import Path

from app import make_server


class ApiTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.server = make_server(Path(self.temp.name) / "http.db", port=0, delay=0)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base = f"http://127.0.0.1:{self.server.server_port}"

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join()
        self.temp.cleanup()

    def request(self, path, data=None, headers=None):
        all_headers = {"Content-Type": "application/json", **(headers or {})}
        req = urllib.request.Request(self.base + path, data=json.dumps(data).encode() if data is not None else None, headers=all_headers)
        try:
            with urllib.request.urlopen(req, timeout=5) as response:
                return response.status, json.load(response)
        except urllib.error.HTTPError as exc:
            return exc.code, json.load(exc)

    def test_http_run_and_export(self):
        status, run = self.request("/api/runs", {"task":"Register the latest invoice from Company X"})
        self.assertEqual(status, 201)
        for _ in range(100):
            _, result = self.request(f"/api/runs/{run['id']}")
            if result["status"] not in ("queued", "running"):
                break
            time.sleep(.02)
        self.assertEqual(result["status"], "completed")
        status, exported = self.request(f"/api/runs/{run['id']}/export")
        self.assertEqual(status, 200)
        self.assertEqual(exported["id"], run["id"])
        _, state = self.request("/api/state")
        self.assertEqual(len(state["invoices"]), 1)

    def test_external_origin_rejected(self):
        status, _ = self.request("/api/runs", {"task":"Register invoice from Acme Cloud"}, {"Origin":"https://attacker.example"})
        self.assertEqual(status, 403)

    def test_untrusted_host_rejected(self):
        status, _ = self.request("/api/state", headers={"Host":"attacker.example"})
        self.assertEqual(status, 403)

    def test_invalid_task_rejected(self):
        for task in (None, 42, "", "x" * 2001):
            status, _ = self.request("/api/runs", {"task":task})
            self.assertEqual(status, 400)

    def test_no_filesystem_traversal(self):
        status, _ = self.request("/../app.py")
        self.assertEqual(status, 404)


if __name__ == "__main__":
    unittest.main()
