import io
import json
import unittest
import urllib.error
from unittest.mock import patch

from worker.providers import OpenAIPlanner, ProviderError


class ProviderTests(unittest.TestCase):
    def planner(self):
        with patch.dict("os.environ", {"OPENAI_API_KEY":"test-placeholder-not-a-real-key", "OPENAI_MODEL":"configured-test-model"}):
            return OpenAIPlanner()

    def response(self, decision):
        return io.BytesIO(json.dumps({"output":[{"type":"function_call", "name":"define_goal", "arguments":json.dumps(decision)}]}).encode())

    def test_responses_wire_format_and_decision(self):
        decision = {"vendor":"Acme Cloud", "scope":"latest", "operation":"register", "question":""}
        with patch("urllib.request.urlopen", return_value=self.response(decision)) as send:
            goal = self.planner().goal("Log the newest invoice from Acme Cloud")
        self.assertEqual(goal["operation"], "register")
        request = send.call_args.args[0]
        payload = json.loads(request.data)
        self.assertEqual(request.full_url, "https://api.openai.com/v1/responses")
        self.assertFalse(payload["store"])
        self.assertTrue(payload["tools"][0]["strict"])
        self.assertFalse(payload["parallel_tool_calls"])

    def test_malformed_model_response_is_rejected(self):
        for result in ({"vendor":42}, {"vendor":"attacker", "scope":"latest", "operation":"register", "question":""}):
            with patch("urllib.request.urlopen", return_value=self.response(result)):
                with self.assertRaises(ProviderError):
                    self.planner().goal("task")

    def test_upstream_error_body_is_not_exposed(self):
        exc = urllib.error.HTTPError("https://api.openai.com", 401, "secret upstream body", {}, None)
        with patch("urllib.request.urlopen", side_effect=exc):
            with self.assertRaises(ProviderError) as caught:
                self.planner().goal("task")
        self.assertIn("401", str(caught.exception))
        self.assertNotIn("secret", str(caught.exception))

    def test_model_mode_requires_explicit_configuration(self):
        with patch.dict("os.environ", {}, clear=True):
            with self.assertRaises(ProviderError):
                OpenAIPlanner()
