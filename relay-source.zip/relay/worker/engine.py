"""Bounded observe → decide → act loop, with executor-owned safety and evidence."""
import hashlib
import json
import re
import threading
import time
import uuid
from datetime import date
from decimal import Decimal, InvalidOperation

from .providers import DemoPlanner, OpenAIPlanner, ProviderError, VENDORS, TOOL_DESCRIPTIONS
from .store import now


class ToolError(Exception):
    def __init__(self, message, retryable=False):
        super().__init__(message)
        self.retryable = retryable


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def parse_invoice(body, source_id, override=None):
    """Strict fixture format; reject duplicate fields and never evaluate document text."""
    fields = {}
    for line in body.splitlines():
        match = re.fullmatch(r"(Vendor|Invoice|Issued|Due|Currency|Amount):\s*(.*)", line)
        if match:
            key, value = match.groups()
            if key in fields:
                raise ToolError(f"Conflicting or duplicate field: {key}")
            fields[key] = value.strip()
    for required in ("Vendor", "Invoice", "Issued", "Currency", "Amount"):
        if not fields.get(required):
            raise ToolError(f"Source is missing {required}; manual review required")
    try:
        amount = Decimal(fields["Amount"])
        if not amount.is_finite() or amount <= 0 or amount > 100000000 or amount.as_tuple().exponent < -2:
            raise ValueError()
        date.fromisoformat(fields["Issued"])
        due = fields.get("Due") or override
        if due:
            date.fromisoformat(due)
            if due < fields["Issued"]:
                raise ValueError()
        if fields["Currency"] != "USD":
            raise ValueError()
    except (ValueError, InvalidOperation):
        raise ToolError("Invalid amount, currency, or date in the source; manual review required") from None
    return {"vendor": fields["Vendor"], "number": fields["Invoice"],
            "amount_cents": int(amount * 100), "currency": fields["Currency"],
            "issued": fields["Issued"], "due": due, "source_id": source_id,
            "source_hash": hashlib.sha256(body.encode()).hexdigest()}


class Engine:
    MAX_STEPS = 36

    def __init__(self, store, delay=0.15, recover=True):
        self.store = store
        self.delay = delay
        self.locks = {}
        self.registry_lock = threading.Lock()
        if recover:
            for run in store.runs():
                if run["status"] in ("running", "queued"):
                    run["status"] = "interrupted"
                    run["summary"] = "Server restarted. Resume to reconcile any completed writes and continue."
                    self.event(run, "interrupted", "Execution interrupted", "Saved progress is available to resume.")

    def lock(self, run_id):
        with self.registry_lock:
            return self.locks.setdefault(run_id, threading.RLock())

    def event(self, run, kind, title, detail="", data=None):
        run["events"].append({"seq": len(run["events"]) + 1, "at": now(), "kind": kind,
                              "title": title, "detail": detail, "data": data})
        run["updated_at"] = now()
        self.store.save_run(run)

    def create(self, task, mode="demo", fault="none", background=True):
        if not isinstance(task, str) or not 3 <= len(task.strip()) <= 2000:
            raise ValueError("Enter a task between 3 and 2,000 characters.")
        if mode not in ("demo", "openai") or fault not in ("none", "inbox_outage", "commit_timeout"):
            raise ValueError("Unknown worker mode or fault scenario")
        if mode == "openai":
            OpenAIPlanner()  # Fail before creating a misleading run when not configured.
        run = {"id": uuid.uuid4().hex[:12], "task": task.strip(), "mode": mode,
               "fault": fault, "fault_used": False, "status": "queued", "goal": None,
               "memory": {}, "events": [], "steps": 0, "retries": {}, "approvals": [],
               "overrides": {}, "pending": None, "summary": "", "created_at": now(), "updated_at": now()}
        self.event(run, "created", "Task received", task.strip())
        if background:
            threading.Thread(target=self.execute, args=(run["id"],), daemon=True).start()
        else:
            self.execute(run["id"])
        return self.store.run(run["id"])

    def planner(self, mode):
        return OpenAIPlanner() if mode == "openai" else DemoPlanner()

    def execute(self, run_id):
        with self.lock(run_id):
            run = self.store.run(run_id)
            if run["status"] not in ("queued", "interrupted"):
                return
            run["status"] = "running"
            self.store.save_run(run)
        try:
            planner = self.planner(run["mode"])
            if not run["goal"]:
                goal = planner.goal(run["task"])
                with self.lock(run_id):
                    if self.store.run(run_id)["status"] != "running":
                        return
                    if goal.get("question"):
                        self.pause(run, {"type": "clarification", "question": goal["question"]})
                        return
                    if goal.get("vendor") not in VENDORS or goal.get("scope") not in ("latest", "all") or goal.get("operation") not in ("register", "summarize"):
                        raise ToolError("Planner proposed an unsupported goal")
                    run["goal"] = goal
                    self.event(run, "plan", "Plan ready", f"{goal['operation'].capitalize()} {goal['scope']} invoices from {goal['vendor']}.",
                               {"steps": ["Find source invoices", "Read and validate fields", "Save to ledger" if goal["operation"] == "register" else "Build source-backed report", "Verify outcome"]})
            while run["steps"] < self.MAX_STEPS:
                if self.store.run(run_id)["status"] != "running":
                    return
                action = planner.next_action(run)
                with self.lock(run_id):
                    # A cancellation during a slow provider call takes effect before the next tool.
                    if self.store.run(run_id)["status"] != "running":
                        return
                    if not isinstance(action, dict) or action.get("tool") not in TOOL_DESCRIPTIONS or not isinstance(action.get("ref"), str):
                        raise ToolError("Planner proposed an invalid tool call")
                    run["steps"] += 1
                    tool, ref = action["tool"], action["ref"]
                    self.event(run, "action", tool, str(action.get("reason", ""))[:500], {"ref": ref})
                    try:
                        observation = self.dispatch(run, tool, ref)
                        self.event(run, "observation", f"{tool} result", observation.get("message", "Action completed"), observation)
                    except ToolError as exc:
                        key = f"{tool}:{ref}"
                        run["retries"][key] = run["retries"].get(key, 0) + 1
                        self.event(run, "error", f"{tool} failed", str(exc), {"retryable": exc.retryable})
                        if tool == "search_inbox" and exc.retryable:
                            run["memory"]["inbox_failed"] = True
                            self.event(run, "recovery", "Switching to archive", "The inbox index is unavailable. The archive contains the same source invoices.")
                        elif exc.retryable and run["retries"][key] <= 2:
                            self.event(run, "recovery", "Safe retry scheduled", "Retrying with invoice identity as the idempotency key; a committed write will be reused.")
                        else:
                            raise
                    if run["status"] != "running":
                        return
                time.sleep(self.delay * min(4, 2 ** run["retries"].get(f"{tool}:{ref}", 0)))
            raise ToolError("Step limit reached. Review the trace before starting another task.")
        except (ToolError, ValueError, ProviderError) as exc:
            with self.lock(run_id):
                if self.store.run(run_id)["status"] != "running":
                    return
                run["status"] = "failed"
                run["summary"] = str(exc)
                self.event(run, "failed", "Task stopped", str(exc))
        except Exception:
            import logging
            logging.exception("Unexpected worker failure for run %s", run_id)
            with self.lock(run_id):
                current = self.store.run(run_id)
                if current["status"] == "running":
                    current["status"] = "failed"
                    current["summary"] = "Unexpected server error. Inspect the server log and saved trace."
                    self.event(current, "failed", "Unexpected error", current["summary"])

    def pause(self, run, pending):
        run["status"] = "waiting"
        run["pending"] = pending
        self.event(run, "waiting", "Your input is needed", pending["question"], pending)

    def selected_ref(self, run, ref):
        if ref not in run["memory"].get("selected", []):
            raise ToolError("Tool reference is outside the selected task sources")

    def dispatch(self, run, tool, ref):
        memory = run["memory"]
        if tool in ("search_inbox", "search_archive"):
            if "selected" in memory:
                raise ToolError("Sources have already been selected")
            if tool == "search_inbox" and run["fault"] == "inbox_outage":
                raise ToolError("Sandbox inbox index returned 503", retryable=True)
            docs = self.store.documents(run["goal"]["vendor"])
            if not docs:
                raise ToolError("No invoice sources found for the requested company")
            selected = docs[:1] if run["goal"]["scope"] == "latest" else docs
            memory["selected"] = [d["id"] for d in selected]
            memory["search_results"] = docs
            return {"message": f"Found {len(docs)} invoice(s); selected {len(selected)} by issue date.", "sources": selected}
        if tool == "finish":
            return self.finish(run)
        self.selected_ref(run, ref)
        if tool == "read_document":
            doc = self.store.document(ref)
            memory.setdefault("documents", {})[ref] = doc
            return {"message": f"Read {doc['subject']}", "document": doc}
        if tool == "extract_invoice":
            doc = memory.get("documents", {}).get(ref)
            if not doc:
                raise ToolError("Read the source before extracting fields")
            facts = parse_invoice(doc["body"], ref, run["overrides"].get(ref))
            if facts["vendor"] != run["goal"]["vendor"] or facts["issued"] != doc["issued"]:
                raise ToolError("Invoice fields disagree with the selected source identity")
            if not facts["due"]:
                self.pause(run, {"type": "missing_date", "ref": ref,
                                 "question": f"{facts['number']} has no due date. Enter a confirmed due date (YYYY-MM-DD).", "invoice": facts})
                return {"message": "Missing due date; paused without inventing a value."}
            memory.setdefault("facts", {})[ref] = facts
            return {"message": f"Validated {facts['number']}: {facts['currency']} {facts['amount_cents']/100:,.2f}, due {facts['due']}.", "invoice": facts,
                    "due_date_origin": "user clarification" if ref in run["overrides"] else "source document"}
        facts = memory.get("facts", {}).get(ref)
        if not facts:
            raise ToolError("Validated source facts are required before this action")
        if tool == "save_invoice":
            if run["goal"]["operation"] != "register":
                raise ToolError("A summary task does not authorize ledger writes")
            # Re-read the source at the write boundary to detect stale evidence.
            if fingerprint(parse_invoice(self.store.document(ref)["body"], ref, run["overrides"].get(ref))) != fingerprint(facts):
                raise ToolError("Source changed after extraction; no write was performed")
            if facts["amount_cents"] >= 1000000 and fingerprint(facts) not in run["approvals"]:
                self.pause(run, {"type": "approval", "ref": ref, "fingerprint": fingerprint(facts), "invoice": facts,
                                 "question": f"Approve recording {facts['currency']} {facts['amount_cents']/100:,.2f} for {facts['vendor']}? Sandbox policy requires approval at $10,000 or more. No payment will be made."})
                return {"message": "Paused before write for approval of these exact invoice values."}
            try:
                result = self.store.save_invoice(facts)
            except ValueError as exc:
                raise ToolError(str(exc)) from None
            if run["fault"] == "commit_timeout" and not run["fault_used"]:
                run["fault_used"] = True
                raise ToolError("Sandbox connection timed out after commit; write outcome is unknown", retryable=True)
            memory.setdefault("saved", {})[ref] = result
            return {"message": "Existing identical invoice reused." if result["duplicate"] else "Invoice saved to the ledger.", **result}
        if tool == "verify_invoice":
            saved = memory.get("saved", {}).get(ref)
            if not saved:
                raise ToolError("Cannot verify an invoice before a save or duplicate lookup")
            record = self.store.invoice(saved["record_id"])
            mismatches = [k for k, v in facts.items() if not record or record.get(k) != v]
            if mismatches:
                raise ToolError("Read-back verification failed for: " + ", ".join(mismatches))
            evidence = {"record_id": record["id"], "source_id": ref, "fields_checked": list(facts),
                        "verified_at": now(), "record": record}
            memory.setdefault("verified", {})[ref] = evidence
            return {"message": "Independent ledger read matches all 8 source fields.", **evidence}
        raise ToolError("Unknown tool")

    def finish(self, run):
        memory = run["memory"]
        selected = memory.get("selected", [])
        required = "verified" if run["goal"]["operation"] == "register" else "facts"
        if not selected or any(ref not in memory.get(required, {}) for ref in selected):
            raise ToolError("Completion rejected: not every selected source has verified evidence")
        # A finish call performs a fresh independent check, even if earlier verification passed.
        for ref in selected:
            facts = memory["facts"][ref]
            current = parse_invoice(self.store.document(ref)["body"], ref, run["overrides"].get(ref))
            if current != facts:
                raise ToolError("Source changed before completion; evidence is stale")
            if required == "verified":
                record = self.store.invoice(memory["verified"][ref]["record_id"])
                if not record or any(record.get(k) != v for k, v in facts.items()):
                    raise ToolError("Ledger changed before completion; verification no longer holds")
        total = sum(memory["facts"][ref]["amount_cents"] for ref in selected)
        verb = "Recorded and verified" if required == "verified" else "Summarized from source"
        details = "; ".join(f"{memory['facts'][ref]['number']} due {memory['facts'][ref]['due']}" for ref in selected)
        run["status"] = "completed"
        run["summary"] = f"{verb} {len(selected)} invoice(s) from {run['goal']['vendor']}, totaling USD {total/100:,.2f}. {details}."
        self.event(run, "completed", "Outcome verified", run["summary"])
        return {"message": run["summary"], "total_cents": total, "source_ids": selected}

    def respond(self, run_id, answer, background=True):
        with self.lock(run_id):
            run = self.store.run(run_id)
            if run["status"] != "waiting":
                raise ValueError("This task is not waiting for input")
            if not isinstance(answer, str) or not answer.strip() or len(answer) > 2000:
                raise ValueError("Provide an answer between 1 and 2,000 characters")
            answer = answer.strip()
            pending = run["pending"]
            if pending["type"] == "approval":
                if answer not in ("approve", "deny"):
                    raise ValueError("Choose approve or deny")
                if answer == "deny":
                    run["status"] = "cancelled"
                    run["pending"] = None
                    run["summary"] = "Approval declined. This invoice was not written; any earlier verified writes remain in the ledger."
                    self.event(run, "cancelled", "Approval declined", run["summary"])
                    return run
                run["approvals"].append(pending["fingerprint"])
            elif pending["type"] == "missing_date":
                if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", answer):
                    raise ValueError("Use YYYY-MM-DD")
                date.fromisoformat(answer)
                if answer < pending["invoice"]["issued"]:
                    raise ValueError("Due date cannot precede the issue date")
                run["overrides"][pending["ref"]] = answer
            else:
                # Full restatement is preferred; a bare known vendor fills a missing target.
                run["task"] = run["task"] + " " + answer if answer in VENDORS else answer
            run["pending"] = None
            run["status"] = "queued"
            self.event(run, "input", "User input received", answer)
        if background:
            threading.Thread(target=self.execute, args=(run_id,), daemon=True).start()
        else:
            self.execute(run_id)
        return self.store.run(run_id)

    def cancel(self, run_id):
        with self.lock(run_id):
            run = self.store.run(run_id)
            if run["status"] not in ("queued", "running", "waiting", "interrupted"):
                raise ValueError("This task has already stopped")
            run["status"] = "cancelled"
            run["pending"] = None
            run["summary"] = "Task cancelled. Any completed writes remain in the ledger; inspect the trace for details."
            self.event(run, "cancelled", "Task cancelled", run["summary"])
            return run

    def resume(self, run_id, background=True):
        with self.lock(run_id):
            run = self.store.run(run_id)
            if run["status"] != "interrupted":
                raise ValueError("Only interrupted tasks can be resumed")
            run["status"] = "queued"
            self.event(run, "recovery", "Resuming saved progress", "Previously committed invoices will be reconciled using their identity.")
        if background:
            threading.Thread(target=self.execute, args=(run_id,), daemon=True).start()
        else:
            self.execute(run_id)
        return self.store.run(run_id)
