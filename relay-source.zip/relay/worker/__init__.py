"""Relay: a small, observable autonomous task worker."""
