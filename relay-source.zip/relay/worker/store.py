"""Durable sandbox data. Every operation uses its own SQLite connection."""
import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path


def now():
    return datetime.now(timezone.utc).isoformat()


FIXTURES = [
    ("doc-acme-09", "Acme Cloud", "AC-2026-0901", "2026-09-01", "2026-09-30", "1840.00"),
    ("doc-acme-10", "Acme Cloud", "AC-2026-1001", "2026-10-01", "2026-10-31", "2480.00"),
    ("doc-northstar-10", "Northstar Labs", "NL-2026-1042", "2026-10-02", "", "3600.00"),
    ("doc-orbit-10", "Orbit Studio", "OS-2026-0088", "2026-10-01", "2026-10-20", "12500.00"),
    ("doc-companyx-10", "Company X", "CX-2026-0100", "2026-10-02", "2026-11-01", "975.50"),
]


class Store:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.executescript("""
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS documents (
                    id TEXT PRIMARY KEY, vendor TEXT NOT NULL, issued TEXT NOT NULL,
                    subject TEXT NOT NULL, body TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS invoices (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, vendor TEXT NOT NULL,
                    number TEXT NOT NULL, amount_cents INTEGER NOT NULL,
                    currency TEXT NOT NULL, issued TEXT NOT NULL, due TEXT NOT NULL,
                    source_id TEXT NOT NULL, source_hash TEXT NOT NULL,
                    created_at TEXT NOT NULL, UNIQUE(vendor, number));
                CREATE TABLE IF NOT EXISTS runs (
                    id TEXT PRIMARY KEY, state TEXT NOT NULL, updated_at TEXT NOT NULL);
            """)
            for doc_id, vendor, number, issued, due, amount in FIXTURES:
                body = (f"INVOICE\nVendor: {vendor}\nInvoice: {number}\nIssued: {issued}\n"
                        f"Due: {due}\nCurrency: USD\nAmount: {amount}\n\n"
                        "Services: Monthly professional services.\nAll data is fictional.\n")
                db.execute("INSERT OR IGNORE INTO documents VALUES (?, ?, ?, ?, ?)",
                           (doc_id, vendor, issued, f"Invoice {number} · {vendor}", body))

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=10)
        db.row_factory = sqlite3.Row
        try:
            with db:
                yield db
        finally:
            db.close()

    def documents(self, vendor=None):
        with self.connect() as db:
            rows = db.execute("SELECT id, vendor, issued, subject FROM documents "
                              "WHERE (? IS NULL OR vendor = ?) ORDER BY issued DESC, id DESC",
                              (vendor, vendor)).fetchall()
        return [dict(r) for r in rows]

    def document(self, doc_id):
        with self.connect() as db:
            row = db.execute("SELECT * FROM documents WHERE id = ?", (doc_id,)).fetchone()
        if not row:
            raise ValueError("Document does not exist")
        return dict(row)

    def invoices(self):
        with self.connect() as db:
            return [dict(r) for r in db.execute("SELECT * FROM invoices ORDER BY id DESC")]

    def invoice(self, record_id):
        with self.connect() as db:
            row = db.execute("SELECT * FROM invoices WHERE id = ?", (record_id,)).fetchone()
        return dict(row) if row else None

    def save_invoice(self, invoice):
        fields = ["vendor", "number", "amount_cents", "currency", "issued", "due", "source_id", "source_hash"]
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            existing = db.execute("SELECT * FROM invoices WHERE vendor = ? AND number = ?",
                                  (invoice["vendor"], invoice["number"])).fetchone()
            if existing:
                if any(existing[k] != invoice[k] for k in fields):
                    raise ValueError("An invoice with this number already exists with different values; review required")
                return {"record_id": existing["id"], "duplicate": True}
            cursor = db.execute(f"INSERT INTO invoices ({', '.join(fields)}, created_at) "
                                f"VALUES ({', '.join(['?'] * 9)})",
                                [invoice[k] for k in fields] + [now()])
            return {"record_id": cursor.lastrowid, "duplicate": False}

    def save_run(self, run):
        with self.connect() as db:
            db.execute("INSERT INTO runs VALUES (?, ?, ?) ON CONFLICT(id) DO UPDATE SET "
                       "state=excluded.state, updated_at=excluded.updated_at",
                       (run["id"], json.dumps(run), now()))

    def run(self, run_id):
        with self.connect() as db:
            row = db.execute("SELECT state FROM runs WHERE id = ?", (run_id,)).fetchone()
        if not row:
            raise KeyError(run_id)
        return json.loads(row["state"])

    def runs(self):
        with self.connect() as db:
            return [json.loads(r["state"]) for r in db.execute("SELECT state FROM runs ORDER BY updated_at DESC LIMIT 100")]
