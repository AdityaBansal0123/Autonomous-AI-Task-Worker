# Technical decisions

## Why invoice operations?

The example is small enough to test rigorously and rich enough to require a genuine feedback loop: ambiguous target selection, ordering by issue date, reading a source, validating missing fields, handling a write whose outcome is unknown, and checking a final record. Generalization is demonstrated across vendors, single/batch scope, and write/report intent using the same executor. It does not demonstrate general computer-use competence.

## Why tools instead of mouse control?

The brief permits a simulated company application or APIs. Direct tools provide precise inputs, explicit errors, and independent read-back without introducing brittle selectors or asking for real credentials. The UI makes the sandbox visible, while the execution engine operates its underlying data. A future browser adapter could implement the same logical tool contracts; it would need new state observation and verification logic.

## Why a planner / executor split?

The planner proposes what to do next. The executor owns capabilities and evidence. A model may choose a poor tool or try to finish early, but it cannot supply arbitrary ledger fields: `save_invoice` accepts only a source reference, and the executor uses facts extracted from that selected source. A summary goal cannot call a write tool successfully. High-value approval is checked at the mutation boundary, independent of the model's rationale.

Goal interpretation is still a semantic trust boundary. The model can misunderstand a user; the narrow offline parser can miss unsupported constraints. A future implementation should explicitly validate or confirm ambiguous goal contracts rather than implying the executor proves all natural-language intent.

## Why a deterministic offline planner?

Reviewers need a reproducible environment that starts with one command and no credentials. It demonstrates tool effects and recovery deterministically. It is clearly labeled as a policy, not advertised as an AI model. The OpenAI adapter replaces goal parsing and action selection; it does not replace the execution, approval, or verification machinery. Model quality must be measured separately with live credentials.

## Why structured decisions?

The optional model uses strict function schemas and selects one action at a time. This keeps each tool result observable before another decision. The application also validates the returned schema locally. It sends an explicit compact state and recent observations on every request; it does not rely on provider conversation storage. It does not execute arbitrary code, browse arbitrary URLs, or allow a model-supplied amount to be written directly.

The trace shows action rationales and observations. It is an audit of behavior, not a display of hidden model reasoning.

## Data and money

Invoice source documents, ledger records, and run snapshots are separate SQLite tables. Source text is hashed, while money is validated with `Decimal` and converted to integer cents. More than two decimal places, nonfinite numbers, nonpositive amounts, unexpected currencies, duplicate labeled fields, and invalid dates are rejected. A missing due date is explicitly user-supplied and marked as such in the trace and UI.

The source hash preserves original-document provenance. The approval fingerprint covers the complete extracted record, including any user-provided due date. The eight compared fields are vendor, invoice number, amount in cents, currency, issue date, due date, source ID, and source hash.

## Failure semantics

| Situation | Behavior | Why |
| --- | --- | --- |
| Inbox index fails | Planner sees failure and selects archive | Demonstrates a real alternative tool path. |
| Save commits, response is lost | Retry the same identity and compare existing values | Reconciles uncertainty without duplicate records. |
| Existing invoice has different values | Stop with a conflict | Never silently overwrite business data. |
| Missing due date | Pause and persist a question | Avoids fabricating required facts. |
| Invoice is at least USD 10,000 | Pause before write, bind approval to fingerprint | Prevents broad or stale approval from authorizing different data. |
| Verification does not match | Fail; no successful receipt | A tool returning success is insufficient evidence. |
| Model fails or emits invalid decision | Stop with an explicit error | Avoids pretending model execution happened. |
| Server restarts during work | Mark interrupted; resume manually | Prevents invisible automatic continuation after process loss. |
| User cancels | Serialize with tool execution, stop before next tool | A currently committed write remains visible and is not rolled back. |

Each run has a lock. Slow model calls happen outside that lock; the engine checks persisted cancellation status before dispatch. Tool mutations and cancellation decisions are serialized. SQLite `BEGIN IMMEDIATE` protects duplicate lookup plus insert against concurrent runs. The unique database constraint is a second defense.

There is an intentional checkpoint gap between ledger commit and run-state save. Invoice idempotency repairs that gap after a restart. This is not a distributed transaction system. Writes can remain after a partially failed batch.

## Completion semantics

For registration, every selected source needs validated facts, a persisted ledger record, and a separate matching read. For a summary, every selected source needs validated facts. At `finish`, the executor re-reads sources and, for registrations, ledger values, rather than relying only on earlier booleans. It constructs the final summary itself. A model cannot inject a success message.

Selection uses a snapshot of available source metadata. It does not guarantee a newly arriving invoice after selection will be included. Verification is point-in-time; stronger guarantees require versioned sources and transactional service APIs.

## Local security boundary

The service listens only on `127.0.0.1`. HTTP Host and Origin checks reject cross-origin browser requests and untrusted hosts. Mutations require JSON content types. Static routes are allowlisted, SQL is parameterized, and document/task text is escaped when rendered. A Content Security Policy restricts scripts, styles, and connections to the same origin. API keys are server-side environment variables.

These controls are appropriate for a local demo; they do not replace authentication, authorization, TLS, rate limiting, tenant isolation, or a production server. Local processes can access the service. There are no arbitrary shell, filesystem, network, payment, or email-sending tools.

## Extension points

- Add new data adapters behind `Store` and `Engine.dispatch`, preserving source identifiers and verifiable writes.
- Add more tools through `TOOL_DESCRIPTIONS`, schema validation, dispatch, and goal-specific completion predicates together.
- Add another model by implementing `goal(task)` and `next_action(run)`.
- Keep verification service-owned. If a new workflow cannot produce independent evidence, do not label it completed.
- Replace JSON snapshot persistence with append-only events and checkpointed jobs before scaling beyond a local prototype.
