# Demo walkthrough

Start with `python app.py` and open http://127.0.0.1:8000.

The [included recording](../artifacts/relay-demo.webm) was captured from a fresh temporary database by `python -m tests.browser_demo --channel chrome`. It is actual browser interaction, not a simulated progress animation. The planner mode in the recording is **Offline demo**. The recording is silent; the UI trace provides the explanation.

1. **Register an invoice with an uncertain save outcome.** Click “Register latest invoice,” select “Timeout after save” under Test recovery, and run. Watch the worker read the newest source, save it, receive the injected timeout, retry, reuse the existing identical record, and independently verify all eight fields. Result: AC-2026-1001, USD 2,480.00, due 2026-10-31; exactly one ledger row.
2. **Inspect the evidence.** Open “Original invoice” in the collected evidence panel. Compare its amount and date with the completion receipt. The full trace is downloadable with Export.
3. **Approve a high-value record.** Select “Approval handoff,” turn fault injection off, and run. Orbit Studio's USD 12,500.00 invoice pauses before writing. Click “Approve record.” The same run continues and verifies the saved invoice. Approval does not send money.
4. **Supply missing information.** Select “Missing information” and run. Northstar Labs' source has no due date. Enter `2026-11-02` as the confirmed date and continue. The source remains unchanged; the trace and evidence identify the user-provided due date.
5. **Use another tool and another goal.** Select “Summarize all invoices,” choose “Inbox unavailable,” and run. The worker switches to the archive, reads both Acme invoices, and returns USD 4,320.00 total without additional writes.
6. **Check the application.** Open Company ledger. It contains three rows, not four: the post-commit retry did not duplicate the Acme record, and the summary did not create a row. Run history contains all four tasks. Source inbox exposes the original five documents.

Other useful checks:

- Run “Register latest invoice from Company X” to exercise the same engine with a different vendor.
- Run “Register all invoices from Acme Cloud” to exercise batch registration.
- Decline an Orbit Studio approval in a fresh sandbox; no record is written.
- Submit “Register the latest invoice” and answer “Acme Cloud” to resolve the target.
- Stop the server at an approval prompt, restart it, and approve from Run history. Pending state survives.
- Run the unit tests to inspect stale-source rejection, read-back mismatch, premature completion, and crash reconciliation that are inconvenient to reproduce manually.

For a fresh demo without deleting prior work, start `python app.py --port 8001 --db data/fresh-demo.db`.
