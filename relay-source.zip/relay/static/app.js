"use strict";
const $ = (selector) => document.querySelector(selector);
const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const money = (cents) => new Intl.NumberFormat("en-US", {minimumFractionDigits:2, maximumFractionDigits:2}).format(cents / 100);
const dateTime = (value) => new Date(value).toLocaleString([], {month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"});
const examples = {
  latest: "Find the latest invoice from Acme Cloud, extract the amount and due date, enter it into our company ledger, and tell me once it is done.",
  summary: "Summarize all invoices from Acme Cloud, including amounts and due dates.",
  approval: "Register the latest invoice from Orbit Studio in the company ledger.",
  missing: "Register the latest invoice from Northstar Labs in the company ledger."
};
let state = {runs:[], invoices:[], documents:[]};
let selectedRun = sessionStorage.getItem("relay-run");
let currentView = "worker";
let renderedRun = "";
let stateSignature = "";
let submitting = false;

async function api(path, data) {
  const response = await fetch(path, data === undefined ? {} : {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(data)});
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || "Request failed");
  return result;
}
function error(message) {
  $("#error").textContent = message;
  $("#error").hidden = !message;
}
function switchView(view) {
  currentView = view;
  document.querySelectorAll(".view").forEach(el => {el.hidden = el.id !== `${view}-view`;});
  document.querySelectorAll(".nav").forEach(el => el.classList.toggle("active", el.dataset.view === view));
  $("#page-label").textContent = {worker:"Task worker",history:"Run history",ledger:"Company ledger",sources:"Source inbox"}[view];
  renderTables();
}
function selectRun(id) {
  selectedRun = id;
  sessionStorage.setItem("relay-run", id);
  renderedRun = "";
  switchView("worker");
  renderRun();
}
function pill(status) { return `<span class="pill ${escapeHtml(status)}">${escapeHtml(status.replaceAll("_", " "))}</span>`; }
function sourceButton(id, text="View source ↗") {
  return `<button class="source-link" data-source="${escapeHtml(id)}">${escapeHtml(text)}</button>`;
}
function renderTables() {
  $("#history-count").textContent = state.runs.length;
  $("#history-list").innerHTML = state.runs.length ? state.runs.map(run => `<button class="history-card" data-run="${escapeHtml(run.id)}"><span class="history-task">${escapeHtml(run.task)}<small>${escapeHtml(dateTime(run.created_at))} &nbsp;·&nbsp; ${run.mode === "demo" ? "Offline planner" : "OpenAI planner"} &nbsp;·&nbsp; ${run.steps} actions</small></span>${pill(run.status)}<span class="history-arrow">↗</span></button>`).join("") : '<div class="empty-state">A clean slate.<br>Your task runs will appear here.</div>';
  $("#ledger-list").innerHTML = state.invoices.length ? `<div class="table-wrap"><table><thead><tr><th>Invoice / company</th><th>Amount</th><th>Due date</th><th>Evidence</th></tr></thead><tbody>${state.invoices.map(i => `<tr><td>${escapeHtml(i.number)}<small>${escapeHtml(i.vendor)} · Record #${i.id}</small></td><td>${escapeHtml(i.currency)} ${money(i.amount_cents)}</td><td>${escapeHtml(i.due)}</td><td>${sourceButton(i.source_id)}</td></tr>`).join("")}</tbody></table></div>` : '<div class="empty-state">No invoices recorded yet.<br>Ask Relay to register an invoice, then check the result here.</div>';
  $("#sources-list").innerHTML = `<div class="sources-grid">${state.documents.map(d => `<button class="source-card" data-source="${escapeHtml(d.id)}"><span>▧</span><h3>${escapeHtml(d.vendor)}</h3><p>${escapeHtml(d.subject)}</p><small>Issued ${escapeHtml(d.issued)} &nbsp; · &nbsp; Open document ↗</small></button>`).join("")}</div>`;
}
function renderRun() {
  const run = state.runs.find(r => r.id === selectedRun);
  if (!run) { $("#execution").hidden = true; $("#welcome").hidden = false; return; }
  $("#execution").hidden = false;
  $("#welcome").hidden = true;
  const signature = JSON.stringify(run);
  if (signature === renderedRun) return;
  renderedRun = signature;
  const priorScroll = $(".timeline")?.scrollTop || 0;
  const pending = run.pending;
  const pendingHtml = pending ? `<div class="pending"><p>${escapeHtml(pending.question)}</p>${pending.type === "approval" ? `<div><button class="button primary" data-answer="approve">Approve record ✓</button> <button class="button danger" data-answer="deny">Decline</button></div>` : `<form id="response-form"><label class="sr-only" for="response">Your answer</label><input id="response" required maxlength="2000" ${pending.type === "missing_date" ? 'type="date"' : 'type="text" placeholder="Enter your clarification…"'}><button class="button primary" type="submit">Continue →</button></form>`}</div>` : "";
  const events = run.events.filter(e => e.kind !== "action" || !run.events.some(next => next.seq === e.seq+1 && next.kind === "observation"));
  const timeline = events.map(e => `<div class="event ${escapeHtml(e.kind)}"><span class="event-icon">${e.kind === "completed" ? "✓" : ""}</span><time>${escapeHtml(new Date(e.at).toLocaleTimeString([], {hour:"2-digit", minute:"2-digit", second:"2-digit"}))}</time><div class="event-title">${escapeHtml(e.title.replaceAll("_", " "))}</div><p class="event-detail">${escapeHtml(e.detail)}</p>${e.data ? `<details><summary>Inspect observation</summary><pre>${escapeHtml(JSON.stringify(e.data,null,2))}</pre></details>` : ""}</div>`).join("");
  const facts = Object.values(run.memory.facts || {});
  const evidence = facts.map(f => { const verified = run.memory.verified?.[f.source_id]; return `<div class="invoice-card"><div class="vendor">${escapeHtml(f.vendor)}</div><div class="invoice-number">${escapeHtml(f.number)}</div><div class="amount"><small>${escapeHtml(f.currency)}</small>${money(f.amount_cents)}</div><dl><dt>Due date</dt><dd>${escapeHtml(f.due)}</dd><dt>Source</dt><dd>${sourceButton(f.source_id,"Original invoice ↗")}</dd>${verified ? `<dt>Ledger record</dt><dd>#${verified.record_id}</dd>` : ""}</dl>${run.overrides[f.source_id] ? '<p class="event-detail">Due date supplied by user clarification.</p>' : ""}<div class="verified-label">${verified ? "✓ All 8 fields verified by read-back" : run.goal?.operation === "summarize" ? "✓ Validated against source document" : "◷ Awaiting ledger verification"}</div></div>`; }).join("") || '<div class="empty-evidence"><span>▧</span>Evidence will appear here<br>as the worker inspects its sources.</div>';
  $("#execution").innerHTML = `<div class="execution-header"><div><h2>Task execution</h2><small>${escapeHtml(run.id)} · ${run.mode === "demo" ? "Deterministic offline planner" : "OpenAI planner"} · ${run.steps}/36 actions</small></div><div class="execution-actions">${pill(run.status)}${["running","queued","waiting","interrupted"].includes(run.status) ? '<button class="button" data-cancel>Stop</button>' : ""}${run.status === "interrupted" ? '<button class="button primary" data-resume>Resume</button>' : ""}<a class="button" href="/api/runs/${run.id}/export" download aria-label="Export execution trace">Export ↗</a></div></div>${pendingHtml}<div class="execution-body"><div class="trace-panel"><div class="panel-label">LIVE EXECUTION TRACE</div><div class="timeline">${timeline}</div></div><div class="evidence-panel"><div class="panel-label">COLLECTED EVIDENCE</div>${evidence}</div></div>${run.summary ? `<div class="outcome ${escapeHtml(run.status)}" role="status">${escapeHtml(run.summary)}</div>` : ""}`;
  if ($(".timeline")) $(".timeline").scrollTop = run.status === "running" ? $(".timeline").scrollHeight : priorScroll;
}
async function refresh() {
  try {
    state = await api("/api/state");
    const sig = JSON.stringify([state.runs.map(r=>[r.id,r.status,r.updated_at]),state.invoices,state.documents]);
    if (sig !== stateSignature) {stateSignature = sig; renderTables();}
    const option = $('#mode option[value="openai"]');
    option.disabled = !state.model_available;
    option.textContent = state.model_available ? `OpenAI · ${state.model}` : "OpenAI · not configured";
    $(".environment").classList.remove("connection-lost");
    $(".environment").innerHTML = "<i></i> Sandbox environment";
    renderRun();
  } catch (e) {
    $(".environment").classList.add("connection-lost");
    $(".environment").textContent = "Connection lost · retrying";
  }
}
async function act(path, data) {
  error("");
  try { await api(path, data); await refresh(); } catch(e) {error(e.message);}
}
document.addEventListener("click", async e => {
  const nav = e.target.closest("[data-view]");
  if (nav) switchView(nav.dataset.view);
  const preset = e.target.closest("[data-example]");
  if (preset) { $("#task").value = examples[preset.dataset.example]; $("#task").focus(); }
  const history = e.target.closest("[data-run]");
  if (history) selectRun(history.dataset.run);
  const source = e.target.closest("[data-source]");
  if (source) {
    try { const doc = await api(`/api/documents/${source.dataset.source}`); $("#source-content").textContent = doc.body; $("#source-dialog").showModal(); }
    catch(err) { switchView("worker"); error(err.message); }
  }
  const answer = e.target.closest("[data-answer]");
  if (answer) await act(`/api/runs/${selectedRun}/respond`, {answer:answer.dataset.answer});
  if (e.target.closest("[data-cancel]")) await act(`/api/runs/${selectedRun}/cancel`, {});
  if (e.target.closest("[data-resume]")) await act(`/api/runs/${selectedRun}/resume`, {});
});
$("#close-dialog").addEventListener("click", () => $("#source-dialog").close());
$("#task-form").addEventListener("submit", async e => {
  e.preventDefault();
  if (submitting) return;
  submitting = true;
  error(""); $("#run-button").disabled = true;
  try {
    const run = await api("/api/runs", {task:$("#task").value, mode:$("#mode").value, fault:$("#fault").value});
    selectedRun = run.id; sessionStorage.setItem("relay-run", run.id); renderedRun = "";
    await refresh();
  } catch(err) {error(err.message);}
  finally {submitting = false; $("#run-button").disabled = false;}
});
document.addEventListener("submit", async e => {
  if (e.target.id === "response-form") {e.preventDefault(); await act(`/api/runs/${selectedRun}/respond`, {answer:$("#response").value});}
});
async function poll() { await refresh(); setTimeout(poll, 700); }
poll();
